'use strict';
// 页面ID
var pageId = $('body').attr('id');

/**
 * 处理主菜单
 */
var handleMainMenu = function () {
    $('#mainMenuToggler').click(function () {
        $('#mainMenu').css('max-height', document.documentElement.clientHeight - 50 + 'px');
    });
};

/**
 * 处理回到顶部按钮
 */
var handleBackToTop = function () {
    $(window).scroll(function () {
        if ($(window).scrollTop() > 100)
            $("#backToTop").fadeIn();
        else
            $("#backToTop").fadeOut();
    });

    $("#backToTop").click(function () {
        $('body, html').animate({scrollTop: 0});
    });
};

/**
 * 处理搜索对话框
 */
var handleSearchDialog = function () {
    var $searchDialog = $('#searchDialog');

    $searchDialog.on('shown.bs.modal', function () {
        $('#searchKeyword').focus();
    }).find('form').submit(function () {
        var $this = $(this);
        var $searchKeyword = $this.find('#searchKeyword');
        var searchType = $this.find('#searchType').val();
        var keyword = $.trim($searchKeyword.val());
        if (searchType === 'gjc') {
            $this.attr('action', pageInfo.rootPath + 'gjc/' + keyword);
        }
        else if (searchType === 'username') {
            $this.attr('action', pageInfo.rootPath + 'user/username/' + keyword);
        }
        else {
            $this.attr('action', pageInfo.rootPath + 'search');
            $searchKeyword.attr('name', searchType === 'author' ? 'pwuser' : 'keyword');
            if (searchType === 'title') {
                if (keyword.length === 1 || (keyword.length === 2 && /^[\w\-]+$/.test(keyword))) {
                    var $method = $this.find('input[name="method"]');
                    $method.val('OR');
                    $searchKeyword.val(keyword + ' ' + Math.floor(new Date().getTime() / 1000));
                    window.setTimeout(function () {
                        $searchKeyword.val(keyword);
                        $method.val('AND');
                    }, 200);
                }
            }
        }
    });

    $searchDialog.find('input[name="searchRange"]').on('click', function () {
        var value = 'all';
        if ($(this).val() === 'current') value = pageInfo.fid;
        $searchDialog.find('input[name="f_fid"]').val(value);
    });

    var $current = $searchDialog.find('input[name="searchRange"][value="current"]');
    $searchDialog.find('#searchType').change(function () {
        var searchType = $(this).val();
        if (!$current.data('enabled')) return;
        $current.prop('disabled', searchType === 'gjc' || searchType === 'username');
    });

    if (pageId === 'threadPage' || pageId === 'readPage') {
        $current.prop('disabled', false).data('enabled', true).click();
    }
};

/**
 * 处理登出按钮
 */
var handleLogoutButton = function () {
    $(document).on('click', '#dropdownItemLogout', function () {
        if (!window.confirm('是否登出账号？')) return false;
    });
};

/**
 * 处理版块页面下的分页导航
 */
var handleThreadPageNav = function () {
    $(document).on('click', '.page-item.active > .page-link', function (e) {
        e.preventDefault();
        var num = parseInt(window.prompt('要跳转到第几页？（共' + pageInfo.maxPageNum + '页）', pageInfo.currentPageNum));
        if (num) {
            var urlParam = pageInfo.urlParam.replace(/&?page=\d*/i, '') + '&page=' + num;
            location.href = pageInfo.rootPath + 'thread?' + urlParam;
        }
    });
};

$(function () {
    if (pageId === 'loginPage') return;

    handleMainMenu();
    handleBackToTop();
    handleSearchDialog();
    handleLogoutButton();
    if (pageId === 'threadPage') {
        handleThreadPageNav();
    }

    //$('[data-toggle="tooltip"]').tooltip();
});
