<?php
namespace app\controller;

use think\Request;
use app\lib\Proxy;
use app\responser;

/**
 * 版块控制器
 * @package app\controller
 */
class Thread extends Base
{
    /**
     * 展示版块页面
     * @param Request $request
     * @return mixed
     */
    public function index(Request $request)
    {
        $response = Proxy::get('thread.php', $request->param());
        $index = new responser\Thread($response);
        $this->assign($index->index());
        return $this->fetch();
    }
}
