# KfMobile
_为这美好的KF献上祝福！_

## 项目简介
本项目为【为这美好的KF献上祝福！】计划第三弹，旨在为广大KFer提供适用于移动浏览器的KF反向代理服务。

## 环境要求
本项目基于ThinkPHP、phpQuery以及Bootstrap打造，环境要求：

    php >= 5.6.0
    cURL PHP Extension
