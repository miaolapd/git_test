<?php
return [
    // 设置开启调试模式，默认值：false
    'app_debug' => true,
    // 应用Trace，默认值：false
    'app_trace' => true,
    // 是否让部分静态资源文件使用CDN（如jquery.js、bootstrap.js），默认值：true
    //'static_file_cdn' => false,
    // 静态资源文件时间戳
    //'static_file_timestamp' => '',
    // 是否关闭网站，默认值：false
    //'site_close' => true,
    // 网站统计脚本
    //'stat_script' => '',
];
